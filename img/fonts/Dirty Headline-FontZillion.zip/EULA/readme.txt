DIRTY HEADLINE
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

Dirty Headline is a "stressed" Swiss-Gothic style font, meant to emulate old poster headers. I created it for FLY FROM EVIL, my crime-drama RPG.

Since It's just for headlines, it's not a full character set - just letters (all caps), numerals, and a few key punctuation marks.

This font is copyright 2001 by S. John Ross. "Dirty Headline" and "Cumberland Games & Diversions" are trademarks of S. John Ross. This font is freeware for personal, non-commercial use of any kind (including website decoration and so on). Contact me at sjohn@io.com if you're interested in a commercial license; rates will depend on the details.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0